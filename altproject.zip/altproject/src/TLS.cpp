// This file is part of libmumble.
// Use of this source code is governed by a BSD-style license
// that can be found in the LICENSE file at the root of the
// Mumble source tree or at <https://www.mumble.info/LICENSE>.

#include "TLS.hpp"

#include "mumble/Cert.hpp"
#include "mumble/Key.hpp"

#include <algorithm>
#include <cassert>
#include <cstddef>
#include <memory>
#include <type_traits>
#include <utility>
#include <vector>
#include <string>   // debug output 
#include <iostream> //std::cout
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>

using namespace mumble;

using Code = SocketTLS::Code;

SocketTLS::SocketTLS(SocketTLS &&socket)
	: SocketTCP(std::move(socket)), m_ssl(std::exchange(socket.m_ssl, nullptr)),
	  m_sslCtx(std::exchange(socket.m_sslCtx, nullptr)), m_closed(socket.m_closed.load()) {
}

SocketTLS::SocketTLS(const int32_t handle, const bool server)
	: SocketTCP(handle), m_ssl(nullptr), m_sslCtx(nullptr), m_closed(true) {
	std::cout << "TLS.cpp SocketTLS::SocketTLS() constructor" << std::endl;
	if (!*static_cast< SocketTCP * >(this)) {
		return;
	}

        std::cout << "TLS.cpp SocketTLS::SocketTLS() : is " << (server ? "SERVER" : "CLIENT") << std::endl;

	// Initialize OpenSSL
	m_sslCtx = SSL_CTX_new(server ? TLS_server_method() : TLS_client_method());
	if (!m_sslCtx) {
		return;
	}
	
	// get client certificate store path
	const char *dir;
	dir = getenv(X509_get_default_cert_dir_env());//SSL_CERT_DIR *nix, org.openssl.winstore win
	if (!dir) dir = X509_get_default_cert_dir();
	std::cout << "TLS.cpp SocketTLS::SocketTLS() Client certificate store path: '" << dir << "'\n" << std::endl;
		
	
	
	#ifdef OS_WINDOWS
		// Use Windows certificate store - OpenSSL v 3.2+ no Windows includes needed here
		// TODO: verify this passes connect with a CA cert
		std::cout << "TLS.cpp SocketTLS::SocketTLS() #def OS_WINDOWS" << std::endl;
		if (SSL_CTX_load_verify_store(m_sslCtx, "org.openssl.winstore://") != 1) {
        		std::cout << "TLS.cpp SocketTLS::SocketTLS() Error: Could not load Windows Certificate Store." << std::endl;
        		ERR_print_errors_fp(stderr);
        		return;
    		}
	#endif
	
	// Create new SSL object
	m_ssl = SSL_new(m_sslCtx);
	if (!m_ssl) {
		return;
	}
	// Link socket to SSL object
	SSL_set_fd(m_ssl, m_handle);
	SSL_set_read_ahead(m_ssl, 1);
	SSL_set_options(m_ssl, SSL_MODE_ENABLE_PARTIAL_WRITE);
	// set verifyCallback function argument to NULL for default disconnects, or to a function
	// that returns 1 for default accepts or 0 for disconnects
	SSL_set_verify(m_ssl, SSL_VERIFY_PEER | SSL_VERIFY_CLIENT_ONCE, nullptr);
	
}

SocketTLS::~SocketTLS() {
	if (m_ssl) {
		SSL_free(m_ssl);
	}

	if (m_sslCtx) {
		SSL_CTX_free(m_sslCtx);
	}
}

SocketTLS::operator bool() const {
	return m_ssl;
}

bool SocketTLS::isServer() const {
	return SSL_is_server(m_ssl);
}

bool SocketTLS::setCert(const Cert::Chain &cert, const Key &key) {
	if (!cert.size()) {
		return false;
	}

	if (SSL_use_certificate(m_ssl, static_cast< X509 * >(cert[0].handle())) <= 0) {
		return false;
	}

	if (cert.size() >= 2) {
		std::for_each(cert.cbegin() + 1, cert.cend(),
					  [this](const Cert &cert) { SSL_add1_chain_cert(m_ssl, cert.handle()); });
	}

	if (SSL_use_PrivateKey(m_ssl, static_cast< EVP_PKEY * >(key.handle())) <= 0) {
		return false;
	}

	if (SSL_check_private_key(m_ssl) <= 0) {
		return false;
	}

	return true;
}

Cert::Chain SocketTLS::peerCert() const {
	Cert::Chain cert;

	const auto stack = SSL_get0_verified_chain(m_ssl);
	for (int i = 0; i < sk_X509_num(stack); ++i) {
		const auto x509 = sk_X509_value(stack, i);
		if (X509_up_ref(x509)) {
			cert.push_back(x509);
		}
	}

	return cert;
}

uint32_t SocketTLS::pending() const {
	int pending = SSL_pending(m_ssl);
	assert(pending >= 0);
	return static_cast< uint32_t >(pending);
}

::Code SocketTLS::accept() {
	ERR_clear_error();

	const auto code = interpretLibCode(SSL_accept(m_ssl));
	if (code == Code::Success) {
		m_closed = false;
	}

	return code;
}

::Code SocketTLS::connect() {
	std::cout << "TLS.cpp SocketTLS::connect() returning ::Code" << std::endl;
	ERR_clear_error();
	// Perform the TLS Handshake
	const auto code = interpretLibCode(SSL_connect(m_ssl));
	// 0 success, 4 disconnect, -2 Failure
	if (code == Code::Success) {
		
		const auto certChain = SocketTLS::peerCert();
		std::cout << "certChain.size(): " << certChain.size() << std::endl;//might always be 1? see node.cpp
		//if(!certChain.size()) {
		//	std::cout << "Invalid SSL Certificates.  See 'VerifySSLCerts' configuration option" << std::endl;
		//	return Shutdown;
		//}
		std::cout << "Peer certificate attributes: " << std::endl;
		const auto attributes = certChain[0].subjectAttributes();
		for (const auto &attribute : attributes) {
			printf("%s: %s\n", attribute.first.data(), attribute.second.data());
		}
		std::cout << "TLS connection established!" << std::endl;
		std::cout << SSL_get_cipher_version(m_ssl) << " " << SSL_get_cipher(m_ssl) << std::endl;
		m_closed = false;
	}

	return code;
}

::Code SocketTLS::disconnect() {
	if (m_closed) {
		return Code::Success;
	}

	m_closed = true;

	ERR_clear_error();

	return interpretLibCode(SSL_shutdown(m_ssl));
}

::Code SocketTLS::read(BufView &buf) {
	ERR_clear_error();

	size_t read   = 0;
	const int ret = SSL_read_ex(m_ssl, buf.data(), buf.size(), &read);

	buf = buf.subspan(read);

	return interpretLibCode(ret, read, buf.size());
}

::Code SocketTLS::write(BufViewConst &buf) {
	ERR_clear_error();

	size_t written = 0;
	const int ret  = SSL_write_ex(m_ssl, buf.data(), buf.size(), &written);

	buf = buf.subspan(written);

	return interpretLibCode(ret, written, buf.size());
}

::Code SocketTLS::interpretLibCode(const int code, const bool processed, const bool remaining) {
	switch (SSL_get_error(m_ssl, code)) {
		case SSL_ERROR_NONE:
			if (processed) {
				return remaining ? Retry : Success;//2 or 0
			}

			return Shutdown;//4
		case SSL_ERROR_ZERO_RETURN:
			std::cout << "TLS.cpp SocketTLS::interpretLibCode() SSL_ERROR_ZERO_RETURN set during connect" << std::endl;
			return Shutdown;//4
		case SSL_ERROR_WANT_READ:
			return WaitIn;//3
		case SSL_ERROR_WANT_WRITE:
			return WaitOut;//3
		case SSL_ERROR_SYSCALL:
			std::cout << "TLS.cpp SocketTLS::interpretLibCode() SSL_ERROR_SYSCALL set during connect\n" << std::endl;
			if (ERR_get_error() == 0 && osErrorToCode(osError()) == mumble::Code::Retry) {
				return Retry;//2
			}
			m_closed = true;

			if (!processed) {
				return Shutdown;
			}
			[[fallthrough]];
		case SSL_ERROR_SSL:
			std::cout << "SSL_ERROR_SSL set during connect; disconnecting" << std::endl;
			unsigned long err;
			while ((err = ERR_get_error()) != 0) {
        			// Convert the raw number into a human-readable string
        			char *error_string = ERR_error_string(err, NULL);
        			std::cout << "SSL_Error_SSL: " << error_string << std::endl;
    			}
			return Failure;//-2
	}

	return Unknown;
}

int SocketTLS::verifyCallback(int, X509_STORE_CTX *) {
	return 1;
}
