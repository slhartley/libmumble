// This file is part of libmumble.
// Use of this source code is governed by a BSD-style license
// that can be found in the LICENSE file at the root of the
// Mumble source tree or at <https://www.mumble.info/LICENSE>.

#include "MumbleInit.hpp"
#include "Node.hpp"
#include "UserManager.hpp"

#include "mumble/Types.hpp"

#include <cstdint>
#include <cstdio>
#include <iostream> //std::cout
#include <memory>
#include <string>
#include <string_view>
#include <unordered_map>
#include <utility>
#include <vector>

#include <toml11/comments.hpp>
#include <toml11/get.hpp>
#include <toml11/parser.hpp>
#include <toml11/value.hpp>

using namespace mumble;

int32_t main(const int argc, const char **argv) {
	/*
	if (argc > 2) {
		printf("Usage: `example_server <config file>`\n");
		return 1;
	}

	std::string confPath = "config.toml";
	if (argc > 1) {
		confPath = argv[1];
	}

	//const auto conf = toml::parse(confPath);
        */
	MumbleInit mumbleInit;
	if (!mumbleInit) {
	 	printf("Main.cpp Unable to initialize mumble\n");
		return 2;
	}

	//auto userManager = std::make_shared< UserManager >(toml::find< uint32_t >(conf, "maxUsers"));
	//initialize UserManager class
	auto userManager = std::make_shared< UserManager >(32);//max 32 connections for now
	//initialize vector of type Node class
	//std::vector< std::unique_ptr< Node > > nodes;
	
	//Initializing ONE Node...
        const uint32_t bandwidth = 1000000;
        //const auto &identity = "node1";
        const auto cert = "cert.pem";
        const auto key = "key.pem";
        //const auto &tcp = "nodes.1.tcp";
        std::string_view tcpIP = "127.0.0.1";
        const uint32_t  tcpPort = 64738;
        //const auto &udp = "nodes.1.udp";
        std::string_view udpIP = "127.0.0.1";
        const uint32_t udpPort = 64740;
	std::cout << "Constructing listening Node::Node" << std::endl;
        auto node = std::make_unique< Node >(userManager, tcpIP, tcpPort, udpIP, udpPort, bandwidth);
	if (!*node) {
		printf("Main.cpp Error 3: Unable to initialize default mumble server node\n");
		return 3;
	}
	
	if (!node->setCert(cert, key)) {
		printf("Main.cpp Error 4: Unable to set credentials\n");
		return 4;
	}
	
	std::cout << "Starting node (TLS.cpp Node::startTCP())..." << std::endl;
	if (!node->start()) {
		printf("Main.cpp Error 5: Unable to start mumble server node\n");
		return 5;
	}

        /*
	for (const auto &nodeConf : toml::find(conf, "nodes").as_table()) {
		const auto bandwidth = toml::find< uint32_t >(nodeConf.second, "bandwidth");

		const auto &identity = toml::find(nodeConf.second, "identity");
		const auto cert      = toml::find< std::string_view >(identity, "cert");
		const auto key       = toml::find< std::string_view >(identity, "key");

		const auto &tcp    = toml::find(nodeConf.second, "tcp");
		const auto tcpIP   = toml::find< std::string_view >(tcp, "ip");
		const auto tcpPort = toml::find< uint32_t >(tcp, "port");

		const auto &udp    = toml::find(nodeConf.second, "udp");
		const auto udpIP   = toml::find< std::string_view >(udp, "ip");
		const auto udpPort = toml::find< uint32_t >(udp, "port");

		auto node = std::make_unique< Node >(userManager, tcpIP, tcpPort, udpIP, udpPort, bandwidth);
		if (!*node) {
			return 3;
		}

		if (!node->setCert(cert, key)) {
			return 4;
		}

		if (!node->start()) {
			return 5;
		}

		nodes.push_back(std::move(node));
	}
        */
	getchar();

	printf("Shutting down...\n");

	return 0;
}
